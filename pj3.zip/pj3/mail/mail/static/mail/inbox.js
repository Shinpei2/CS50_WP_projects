document.addEventListener('DOMContentLoaded', function() {

  /* ヘッダのボタンを押下した際に呼び出す関数を定義 */
  // inbox、sent、archived、ボタンを押したら、関数load_mailbox()を呼び出す
  document.querySelector('#inbox').addEventListener('click', () => load_mailbox('inbox'));
  document.querySelector('#sent').addEventListener('click', () => load_mailbox('sent'));
  document.querySelector('#archived').addEventListener('click', () => load_mailbox('archive'));

  // Submit時の呼出関数を定義
  document.querySelector("#compose-form").onsubmit = send_email;

  // Compaseボタンを押したら、関数compose_mailbox()を呼び出す
  document.querySelector('#compose').addEventListener('click', compose_email);

  // By default, load the inbox（ページロード時は、inboxページを開く）
  load_mailbox('inbox');
});

// Viewの定義1：
function compose_email() {

  // 表示するViewの設定
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';
  document.querySelector('#email-detail-view').style.display = 'none';
  
  // ボタン呼び出しはaddEventListerで定義（1行目～）

  // Clear out composition fields
  document.querySelector('#compose-recipients').value = '';
  document.querySelector('#compose-subject').value = '';
  document.querySelector('#compose-body').value = '';
}


// Viewの定義2：
function load_mailbox(mailbox) {
  
  // Show the mailbox and hide other views
  document.querySelector('#emails-view').style.display = 'block';
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#email-detail-view').style.display = 'none';

  // Show the mailbox name（引数の値をh3タグで表示）
  document.querySelector('#mailbox_name').innerHTML = `${mailbox.charAt(0).toUpperCase() + mailbox.slice(1)}`;

  console.log(`/emails/${mailbox}`);
  fetch(`/emails/${mailbox}`)
    .then(response => response.json())
    .then(emails => {

      // HTML内に表示していたメールを削除
      const email_elements = document.querySelectorAll('.email');
      console.log(email_elements);
      email_elements.forEach(emeil_element => {
        emeil_element.remove();
      })

      // 取得したメール一覧をHTMLに表示
      console.log(emails);
      emails.forEach(email => {
        console.log(email);
        const element = document.createElement('div');
        element.className = "email"
        element.innerHTML = `<p class="box1">${email.sender}  |  ${email.subject}  |  ${email.timestamp}</p>`;

        if (email.read){
          element.style.backgroundColor = 'white';
        } else {
          element.style.backgroundColor = '#CCCCCC';
        }
        // elementがクリックされた際、メール詳細ページへ移動
        element.addEventListener('click', function () {
          console.log(`Go to Mail Detail Page - Subject: ${email.subject}!`)
          load_email(mailbox, email);
        });
        document.querySelector('#emails-view').append(element);
      });

    })
    .catch (error => {
      // errorログをconsoleに表示
      console.log('Error:', error);
    });
}


// Viewの定義3：
function load_email(mailbox_name, email) {
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'none';
  document.querySelector('#email-detail-view').style.display = 'block';
  
  // 引数をログ表示
  console.log(`mailbox_name: ${mailbox_name}`);
  console.log(email);

  // 未読の場合は、Read＝Trueに設定
  if (email.read == false) {
    console.log("メールを既読状態に変更。")
    fetch(`/emails/${email.id}`, {
      method: 'PUT',
      body: JSON.stringify({
        read: true
      })
    }).then()
      .catch(error => { console.log('Error:', error); });
  } else {
    console.log("既に既読状態のため処理なし");
  }

  // 事前のメール情報を削除
  document.querySelector("#email_overview").remove();
  document.querySelector("#mail_body_content").remove();

  // 取得したMail情報を表示
  const h_element = document.createElement('div');
  h_element.id = "email_overview";
  h_element.innerHTML = `<p><b>From:</b> ${email.sender}<br/>`
    + `<b>To:</b> ${email.recipients}<br/>`
    + `<b>Subject:</b> ${email.subject}<br/>`
    + `<b>Timestamp:</b> ${email.timestamp}</p>`;
  document.querySelector('#email-header').prepend(h_element);
  
  const b_element = document.createElement('textarea');
  b_element.classList.add("textarea-primary");
  b_element.id = "mail_body_content";
  b_element.readOnly = true;
  b_element.innerHTML = email.body;
  document.querySelector('#mail_body').append(b_element);

  // ボタン表示の設定
  if (mailbox_name == "sent") {
    // sentの場合は全てのボタンを非表示化
    console.log("Sent：ボタンを非表示");
    document.querySelector("#back_button").style.display = 'none';
    document.querySelector("#archive_button").style.display = 'none';
    document.querySelector("#unarchive_button").style.display = 'none';

  } else {
    // Replyボタン
    console.log("Sent以外の場合はボタンを表示");
    document.querySelector("#back_button").style.display = 'block';
    // Replyボタン押下時に関数呼出
    document.querySelector('#back_button').onclick = function () {
      console.log(` Go to Replay!  Subject: ${email.subject}`);
      reply_email(email);
    };

    // Archive/Unarchiveボタン
    if (email.archived) {
      // アーカイブ済み→「Unarcive」ボタンのみを表示
      console.log("Already Archived !");
      document.querySelector("#archived_id").innerHTML = "Archived";
      document.querySelector("#archived_id").className = "archived";
      document.querySelector("#archive_button").style.display = 'none';
      document.querySelector("#unarchive_button").style.display = 'block';
    } else {
      // 非アーカイブ→「Arcive」ボタンのみを表示
      console.log("Not Archived !");
      document.querySelector("#archived_id").innerHTML = "";
      document.querySelector("#archived_id").classList.remove("archived");
      document.querySelector("#archive_button").style.display = 'block';
      document.querySelector("#unarchive_button").style.display = 'none';
    }
    // Arrchiveボタン押下時に関数呼出
    document.querySelector('#archive_button').onclick = function () {
      archive_button(email);
    };
    // Unarchiveボタン押下時に関数呼出
    document.querySelector('#unarchive_button').onclick = function () {
      unarchive_button(email);
    };
  }
}


// Viewの定義4：
function reply_email(email){
  // 表示するViewの設定
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';
  document.querySelector('#email-detail-view').style.display = 'none';

  // Clear out composition fields
  document.querySelector('#compose-recipients').value = email.sender;
  document.querySelector('#compose-subject').value = `RE: ${email.subject}`;
  document.querySelector('#compose-body').value = `\n\n----------------------------------------\n${email.timestamp} ${email.sender} \nwrote:\n----------\n${email.body}`;
  console.log(`${email.timestamp} ${email.sender} wrote: ${email.body}`);
}



/* 関数定義 */
function send_email() {
  // Formの情報を取得
  const f_recipients = document.querySelector("#compose-recipients").value;
  const f_subject = document.querySelector("#compose-subject").value;
  const f_body = document.querySelector("#compose-body").value;
  // console.log(`recipients: ${f_recipients}`);
  // console.log(`subjects: ${f_subject}`);
  // console.log(`body: ${f_body}`);

  // MailをPOST
  fetch('/emails', {
    method: 'POST',
    body: JSON.stringify({
      recipients: f_recipients,
      subject: f_subject,
      body: f_body
    })
  })
    .then(response => response.json())
      .then(result => {
        // Print result
        console.log(result);

        if ("message" in result) {
          // メール送信が成功した場合は、Sentへ遷移
          load_mailbox('sent');
        }

        if ("error" in result) {
          // Errorの場合、送信を中止。Toの部分にMessageを表示
          document.querySelector('#to-text-error-message').innerHTML = result['error']
        }
      })
      .catch (error => {
      // errorログをconsoleに表示
      console.log('Error:', error);
  });
  // 送信できなかった場合、ページ遷移を中止
  return false;
}

function archive_button(email) {
  console.log(` Go to Archive ${email.subject}`);
  console.log(email);
  // Archiveを変更
  fetch(`/emails/${email.id}`, {
    method: 'PUT',
    body: JSON.stringify({
      archived: true
    })
  }).then()
    .catch(error => { console.log('Error:', error); });
  // archiveメールボックス一覧へ
  setTimeout(() => { load_mailbox('archive'); }, 500);
}

function unarchive_button(email){
  console.log(` Go to Unarchive ${email.subject}`);
  console.log(email);
  // Archiveを変更
  fetch(`/emails/${email.id}`, {
    method: 'PUT',
    body: JSON.stringify({
      archived: false
    })
  }).then()
    .catch(error => { console.log('Error:', error); });
  // archiveメールボックス一覧へ
  setTimeout(() => { load_mailbox('archive');}, 500);
}