from django.shortcuts import render, redirect
from . import util
import random

def get_redirect_url(entry_name):
    # その記事ページへRedirect
    redirect_url = '/wiki/' + entry_name
    print("redirect_url: ", redirect_url)
    return redirect_url

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def wiki(request, entry):
    # title名でファイルを検索
    content = util.get_entry(entry)
    # print("content:", content)
    if (content):
        param = {
            'entry':entry,
            'content':content
        }
        return render(request, "encyclopedia/wiki.html", param)
    else:
        request.session['error_message'] = "Entry Page is Not found!"
        return redirect('error')

def create(request):
    if request.method == "GET":
        print("Get method")
        return render(request, "encyclopedia/create.html", {
        "entries": util.list_entries()
        })
    elif request.method == "POST":
        print("Post method")
        # T1: title検索→Null or 重複の場合、404エラー
        entry = request.POST.get('entry')
        content = request.POST.get('content')
        print("entry: " + entry, "content:" + content)
        print(util.get_entry(entry))

        if util.get_entry(entry) or content == None:
            # 登録済みならエラー
            print("登録済")
            request.session['error_message'] = 'This entry name is already registered!'
            return redirect('error')
        else:
            # Noneなら登録
            print("未登録なので保存")
            with open(f"entries/{entry}.md", "w") as file:
                file.write(content)
            # その記事ページへRedirect
            return redirect(get_redirect_url(entry))


def search(request):
    print("Post method")
    q_word = request.POST.get('q')
    all_entries = util.list_entries()
    if q_word in all_entries:
        print("titleが完全一致: ", q_word)
        # その記事ページへRedirect
        return redirect(get_redirect_url(q_word))
    else:
        print("title完全一致なし。部分検索: ", q_word)
        entries = []
        for entry in all_entries:
            if q_word.lower() in entry.lower():
                entries.append(entry)
        print(entries)
        params = {
            "q_word":q_word,
            "entries": entries
        }
        return render(request, "encyclopedia/search.html", params)

def edit(request, entry):
    # entry名からcontentを取得
    content = util.get_entry(entry)
    if request.method == "GET":
        print("content:", content)
        param = {
        'entry':entry,
        'content':content
        }
        return render(request, "encyclopedia/edit.html", param)
    elif request.method == "POST":
        # 更新：Formから新しいcontentを取得
        content = request.POST.get('content')
        print("New content:", content)
        util.save_entry(entry, content)
        
        # その記事ページへRedirect
        return redirect(get_redirect_url(entry))


    

def error(request):
    error_message = request.session['error_message']
    del request.session['error_message']
    param = {
        'error_message':error_message
    }
    return render(request, "encyclopedia/error.html", param)

def random_page(request):
    all_entries = util.list_entries()
    random_entry = random.choice(all_entries)
    print("all_entries:", all_entries)
    print("random_entry:", random_entry)
    return redirect(get_redirect_url(random_entry))