from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator


class User(AbstractUser):
    pass

# 新規作成
class Category(models.Model):
    category_name = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.category_name}"

class Bid(models.Model):
    start_bid = models.IntegerField(blank=False, null=False, default=1, validators=[MinValueValidator(1)])
    current_bid = models.IntegerField(blank=False, null=False, default=1, validators=[MinValueValidator(1)])

    def __str__(self):
        return f"BID_ID{self.id}　初期価格：{self.start_bid}$　現在価格：{self.current_bid}$"

    

    
class Listing(models.Model):
    category_id = models.ForeignKey(Category, on_delete=models.CASCADE)
    title = models.CharField(max_length=100, blank=False)
    description = models.CharField(max_length=4000)
    bid_id = models.ForeignKey(Bid, on_delete=models.CASCADE)
    image = models.CharField(max_length=1000, blank=True)
    close = models.BooleanField(default=False)
    # 同じテーブルを参照する場合は、related_nameを付与する
    creator_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name="creator")
    owner_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name="owner")

    def __str__(self):
        return f"商品名：{self.title} /　作成者：{self.creator_id}　/　所有者：{self.owner_id}"

class Comment(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    listing_id = models.ForeignKey(Listing, on_delete=models.CASCADE)
    content = models.CharField(max_length=1000, blank=False)

class Watchlist(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    listing_id = models.ForeignKey(Listing, on_delete=models.CASCADE)

    def __str__(self):
        return f"ID:{self.id}　/　ユーザー：{self.user_id.username} /　リスト：{self.listing_id.title}"
