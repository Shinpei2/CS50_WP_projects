from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from .models import User, Category, Bid, Listing, Comment, Watchlist


def index(request):
    # T-1: データベースからActive（close = False）なList一覧を取得・リスト格納
    params = {
        "listings": Listing.objects.filter(close=False)
    }
    return render(request, "auctions/index.html", params)


def close_listings(request):
    # T-1: データベースからinActive（close = True）なList一覧を取得・リスト格納
    params = {
        "listings": Listing.objects.filter(close=True)
    }
    return render(request, "auctions/close_listings.html", params)

def category(request):
    params = {
        "categories": Category.objects.all()
    }
    return render(request, "auctions/category.html", params)


def category_listings(request, category_id):
    print(Listing.objects.filter(category_id=category_id))
    params = {
        "category_name": Category.objects.get(pk=category_id).category_name,
        "listings": Listing.objects.filter(category_id=category_id)
    }
    return render(request, "auctions/category_listings.html", params)


def watchlist(request):
    user = request.user
    my_watchlist = Watchlist.objects.filter(user_id=user)
    listing_ids = [w.listing_id.id for w in my_watchlist]
    print(Listing.objects.filter(id__in=listing_ids))
    params = {
        "listings": Listing.objects.filter(id__in=listing_ids)
    }
    return render(request, "auctions/watchlist.html", params)

def create(request):
    if request.method == "GET":
        params = {
            "categories": Category.objects.all()
        }
        return render(request, "auctions/create.html", params)
    elif request.method == "POST":
        user = request.user
        print(user)
        # print(request.POST["category_id"])
        # print(request.POST["title"])
        # print(request.POST["description"])
        # print(request.POST["start_bid"])
        # print(request.POST["image"])
        c = Category.objects.get(pk=request.POST["category_id"])
        print(c)

        b = Bid(start_bid=request.POST["start_bid"],
                  current_bid=request.POST["start_bid"])
        b.save()
        print(b)

        l = Listing(category_id=c,
                    title=request.POST["title"],
                    description=request.POST["description"],
                    bid_id=b,
                    image=request.POST["image"],
                    close=False,
                    creator_id=user,
                    owner_id=user
            )
        l.save()
        print(l)
        return HttpResponseRedirect(reverse("index"))
    
def listing(request, listing_id):
    listing = Listing.objects.get(id=listing_id)
    bidable_bid = listing.bid_id.current_bid + 1
    # print(bidable_bid)
    comments = Comment.objects.all()

    params = {
        "listing": listing, 
        "bidale_bid": bidable_bid,
        "comments": comments
    }
    return render(request, "auctions/listing.html", params)

def bid(request, listing_id):
    if request.method == "POST":
        listing = Listing.objects.get(id=listing_id)
        # bidの更新
        print("bid_id:", listing.bid_id.id)
        print("new_bid:", request.POST["new_bid"])
        b = Bid(id=listing.bid_id.id)
        print(b)
        b.current_bid = request.POST["new_bid"]
        b.save()
        print(b)

        # Listingの更新
        print(request.user)
        print(listing_id)
        print(listing)
        listing.owner_id = request.user
        print(listing)
        listing.save()
        return HttpResponseRedirect(reverse("listing", args=(listing_id,)))


def close(request, listing_id):
    if request.method == "POST":
        listing = Listing.objects.get(id=listing_id)
        # Listingの更新
        print(listing.close)
        listing.close = True
        print(listing.close)
        listing.save()
        return HttpResponseRedirect(reverse("close_listings", args=()))


def add_watchlist(request, listing_id):
    if request.method == "POST":
        # 登録済みかを確認
        listing = Listing.objects.get(id=listing_id)
        print(Watchlist.objects.filter(user_id=request.user, listing_id=listing))
        if Watchlist.objects.filter(user_id=request.user, listing_id=listing):
            # 追加済
            print("True処理：登録しない")
        else:
            # WL追加
            print("False処理：登録する")
            w = Watchlist(user_id=request.user, listing_id=listing)
            w.save()

        return HttpResponseRedirect(reverse("watchlist", args=()))


def comment(request, listing_id):
    if request.method == "POST":
        # 登録済みかを確認
        listing = Listing.objects.get(id=listing_id)

        print("User:", request.user)
        print("Listing:", listing)
        print("Content:", request.POST["content"])

        c = Comment(user_id=request.user, listing_id=listing,
                    content=request.POST["content"])
        c.save()

        return HttpResponseRedirect(reverse("listing", args=(listing_id,)))





#----------------------------------------------------------------------#
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")
