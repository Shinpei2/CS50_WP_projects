from django.contrib import admin

from .models import User, Category, Bid, Listing, Comment, Watchlist

# Register your models here.
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "category_name")

class BidAdmin(admin.ModelAdmin):
    list_display = ("id", "start_bid", "current_bid")


class ListingAdmin(admin.ModelAdmin):
    list_display = ("id", "category_id", "title", "description", "bid_id", "image", "close", "creator_id", "owner_id")


class CommentAdmin(admin.ModelAdmin):
    list_display = ("id", "user_id", "listing_id", "content")


class CommentAdmin(admin.ModelAdmin):
    list_display = ("id", "user_id", "listing_id")


admin.site.register(User)
admin.site.register(Category)
admin.site.register(Bid)
admin.site.register(Listing)
admin.site.register(Comment)
admin.site.register(Watchlist)
